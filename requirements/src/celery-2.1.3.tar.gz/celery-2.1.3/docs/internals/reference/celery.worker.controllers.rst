=======================================================
 Worker Controller Threads - celery.worker.controllers
=======================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.controllers

.. automodule:: celery.worker.controllers
    :members:
    :undoc-members:
