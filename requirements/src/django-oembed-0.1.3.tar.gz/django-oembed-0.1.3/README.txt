=======================
django-oembed
=======================

This is a collection of tools for Django to allow for replacing links in text
with OEmbed.  This application also provides utilities to make this process not
prohibitively expensive CPU-wise.

For installation instructions, read INSTALL.txt.

Visit the google code page at http://django-oembed.googlecode.com/